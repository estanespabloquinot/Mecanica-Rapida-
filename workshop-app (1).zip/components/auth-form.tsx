"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function AuthForm() {
  const [empresa, setEmpresa] = useState("")
  const [usuario, setUsuario] = useState("")
  const [senha, setSenha] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implementar lógica de autenticação
    console.log("Login:", { empresa, usuario, senha })
  }

  const handleCadastro = async (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implementar lógica de cadastro
    console.log("Cadastro:", { empresa, usuario, senha })
  }

  return (
    <form className="space-y-4">
      <div>
        <Label htmlFor="empresa">Empresa</Label>
        <Input id="empresa" value={empresa} onChange={(e) => setEmpresa(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="usuario">Usuário</Label>
        <Input id="usuario" value={usuario} onChange={(e) => setUsuario(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="senha">Senha</Label>
        <Input id="senha" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required />
      </div>
      <div className="space-x-2">
        <Button onClick={handleLogin}>Entrar</Button>
        <Button onClick={handleCadastro}>Cadastrar</Button>
      </div>
    </form>
  )
}

