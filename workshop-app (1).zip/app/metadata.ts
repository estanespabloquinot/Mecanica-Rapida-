export const metadata = {
  generator: "v0.dev",
}

