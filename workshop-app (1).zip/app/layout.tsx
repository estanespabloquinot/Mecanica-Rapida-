import "./globals.css"
import { Inter } from "next/font/google"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AuthProvider } from "@/contexts/AuthContext"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <AuthProvider>
          <header className="bg-primary text-primary-foreground p-4">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold">Aplicativo da Oficina</h1>
              <nav>
                <Button asChild variant="ghost" className="mr-2">
                  <Link href="/">Início</Link>
                </Button>
                <Button asChild variant="ghost" className="mr-2">
                  <Link href="/veiculos">Veículos</Link>
                </Button>
                <Button asChild variant="ghost" className="mr-2">
                  <Link href="/checklist">Checklist</Link>
                </Button>
                <Button asChild variant="ghost">
                  <Link href="/historico">Histórico</Link>
                </Button>
              </nav>
            </div>
          </header>
          <main className="container mx-auto p-4">{children}</main>
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
