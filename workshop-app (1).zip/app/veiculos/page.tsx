"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/contexts/AuthContext"

interface Veiculo {
  id: string
  placa: string
  kmOleoMotor: number
  kmOleoCaixa: number
  kmOleoDiferencial: number
}

export default function VeiculosPage() {
  const [placa, setPlaca] = useState("")
  const [kmOleoMotor, setKmOleoMotor] = useState("")
  const [kmOleoCaixa, setKmOleoCaixa] = useState("")
  const [kmOleoDiferencial, setKmOleoDiferencial] = useState("")
  const [veiculos, setVeiculos] = useState<Veiculo[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const storedVeiculos = localStorage.getItem("veiculos")
    if (storedVeiculos) {
      setVeiculos(JSON.parse(storedVeiculos))
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      console.error("Usuário não autenticado")
      return
    }

    const novoVeiculo: Veiculo = {
      id: Date.now().toString(),
      placa,
      kmOleoMotor: Number(kmOleoMotor),
      kmOleoCaixa: Number(kmOleoCaixa),
      kmOleoDiferencial: Number(kmOleoDiferencial),
    }

    const novosVeiculos = [...veiculos, novoVeiculo]
    setVeiculos(novosVeiculos)
    localStorage.setItem("veiculos", JSON.stringify(novosVeiculos))

    setPlaca("")
    setKmOleoMotor("")
    setKmOleoCaixa("")
    setKmOleoDiferencial("")
  }

  if (!user) {
    return <div>Você precisa estar logado para acessar esta página.</div>
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Cadastro de Veículo</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="placa">Placa</Label>
          <Input id="placa" value={placa} onChange={(e) => setPlaca(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="kmOleoMotor">KM Troca de Óleo do Motor</Label>
          <Input
            id="kmOleoMotor"
            type="number"
            value={kmOleoMotor}
            onChange={(e) => setKmOleoMotor(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="kmOleoCaixa">KM Troca de Óleo da Caixa</Label>
          <Input
            id="kmOleoCaixa"
            type="number"
            value={kmOleoCaixa}
            onChange={(e) => setKmOleoCaixa(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="kmOleoDiferencial">KM Troca de Óleo do Diferencial</Label>
          <Input
            id="kmOleoDiferencial"
            type="number"
            value={kmOleoDiferencial}
            onChange={(e) => setKmOleoDiferencial(e.target.value)}
            required
          />
        </div>
        <Button type="submit">Cadastrar Veículo</Button>
      </form>

      <h2 className="text-xl font-bold mt-8">Veículos Cadastrados</h2>
      <ul className="space-y-2">
        {veiculos.map((veiculo) => (
          <li key={veiculo.id} className="border p-2 rounded">
            <p>Placa: {veiculo.placa}</p>
            <p>KM Óleo Motor: {veiculo.kmOleoMotor}</p>
            <p>KM Óleo Caixa: {veiculo.kmOleoCaixa}</p>
            <p>KM Óleo Diferencial: {veiculo.kmOleoDiferencial}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

