"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useAuth } from "@/contexts/AuthContext"

export default function Home() {
  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const { user, login, logout } = useAuth()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await login(email, senha)
    } catch (error) {
      console.error("Erro no login:", error)
      // TODO: Mostrar mensagem de erro para o usuário
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-4xl font-bold mb-8">Bem-vindo a Mecanica Rapida 210</h1>
      {user ? (
        <div className="space-y-4">
          <p>Olá, {user.nome}!</p>
          <Button onClick={logout}>Sair</Button>
          <div className="space-y-2">
            <Button asChild className="w-full">
              <Link href="/veiculos">Cadastrar Veículo</Link>
            </Button>
            <Button asChild className="w-full">
              <Link href="/checklist">Novo Checklist</Link>
            </Button>
            <Button asChild className="w-full">
              <Link href="/historico">Ver Histórico</Link>
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="senha">Senha</Label>
              <Input id="senha" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required />
            </div>
            <Button type="submit">Entrar</Button>
          </form>
          <p>
            Não tem uma conta?{" "}
            <Link href="/cadastro" className="text-blue-500 hover:underline">
              Cadastre-se
            </Link>
          </p>
        </div>
      )}
    </div>
  )
}

