"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface Tarefa {
  id: number
  texto: string
  concluida: boolean
}

export default function TarefasPage() {
  const [tarefas, setTarefas] = useState<Tarefa[]>([])
  const [novaTarefa, setNovaTarefa] = useState("")

  const adicionarTarefa = () => {
    if (novaTarefa.trim()) {
      setTarefas([...tarefas, { id: Date.now(), texto: novaTarefa, concluida: false }])
      setNovaTarefa("")
    }
  }

  const toggleTarefa = (id: number) => {
    setTarefas(tarefas.map((tarefa) => (tarefa.id === id ? { ...tarefa, concluida: !tarefa.concluida } : tarefa)))
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Minhas Tarefas</h1>
      <div className="flex space-x-2">
        <Input value={novaTarefa} onChange={(e) => setNovaTarefa(e.target.value)} placeholder="Nova tarefa" />
        <Button onClick={adicionarTarefa}>Adicionar</Button>
      </div>
      <ul className="space-y-2">
        {tarefas.map((tarefa) => (
          <li key={tarefa.id} className="flex items-center space-x-2">
            <Checkbox
              id={`tarefa-${tarefa.id}`}
              checked={tarefa.concluida}
              onCheckedChange={() => toggleTarefa(tarefa.id)}
            />
            <Label htmlFor={`tarefa-${tarefa.id}`} className={tarefa.concluida ? "line-through" : ""}>
              {tarefa.texto}
            </Label>
          </li>
        ))}
      </ul>
    </div>
  )
}

