"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/AuthContext"

interface Checklist {
  id: string
  placa: string
  kmAtual: number
  data: string
  usuarioId: string
}

export default function HistoricoPage() {
  const [checklists, setChecklists] = useState<Checklist[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const storedChecklists = localStorage.getItem("checklists")
    if (storedChecklists) {
      setChecklists(JSON.parse(storedChecklists))
    }
  }, [])

  const handleEditar = (id: string) => {
    console.log("Editar checklist:", id)
    // Implementar lógica de edição
  }

  const handleExcluir = (id: string) => {
    const novosChecklists = checklists.filter((checklist) => checklist.id !== id)
    setChecklists(novosChecklists)
    localStorage.setItem("checklists", JSON.stringify(novosChecklists))
  }

  if (!user) {
    return <div>Você precisa estar logado para acessar esta página.</div>
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Histórico de Manutenção</h1>
      <ul className="space-y-4">
        {checklists.map((checklist) => (
          <li key={checklist.id} className="border p-4 rounded">
            <p>Data: {new Date(checklist.data).toLocaleString()}</p>
            <p>Placa: {checklist.placa}</p>
            <p>KM Atual: {checklist.kmAtual}</p>
            <div className="mt-2 space-x-2">
              <Button onClick={() => handleEditar(checklist.id)}>Editar</Button>
              <Button onClick={() => handleExcluir(checklist.id)} variant="destructive">
                Excluir
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

