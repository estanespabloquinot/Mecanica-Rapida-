"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/contexts/AuthContext"

export default function CadastroPage() {
  const [nome, setNome] = useState("")
  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const [empresa, setEmpresa] = useState("")
  const { cadastrar } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await cadastrar(nome, email, senha, empresa)
      router.push("/") // Redireciona para a página inicial após o cadastro
    } catch (error) {
      console.error("Erro no cadastro:", error)
      // TODO: Mostrar mensagem de erro para o usuário
    }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Cadastro de Usuário e Empresa</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="nome">Nome</Label>
          <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="email">E-mail</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="senha">Senha</Label>
          <Input id="senha" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="empresa">Empresa</Label>
          <Input id="empresa" value={empresa} onChange={(e) => setEmpresa(e.target.value)} required />
        </div>
        <Button type="submit">Cadastrar</Button>
      </form>
    </div>
  )
}

