"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function VehiclesPage() {
  const [plate, setPlate] = useState("")
  const [engineOilKm, setEngineOilKm] = useState("")
  const [transmissionOilKm, setTransmissionOilKm] = useState("")
  const [differentialOilKm, setDifferentialOilKm] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implement vehicle registration logic
    console.log("Vehicle registered:", { plate, engineOilKm, transmissionOilKm, differentialOilKm })
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Vehicle Registration</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="plate">License Plate</Label>
          <Input id="plate" value={plate} onChange={(e) => setPlate(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="engineOilKm">Engine Oil Change KM</Label>
          <Input
            id="engineOilKm"
            type="number"
            value={engineOilKm}
            onChange={(e) => setEngineOilKm(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="transmissionOilKm">Transmission Oil Change KM</Label>
          <Input
            id="transmissionOilKm"
            type="number"
            value={transmissionOilKm}
            onChange={(e) => setTransmissionOilKm(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="differentialOilKm">Differential Oil Change KM</Label>
          <Input
            id="differentialOilKm"
            type="number"
            value={differentialOilKm}
            onChange={(e) => setDifferentialOilKm(e.target.value)}
            required
          />
        </div>
        <Button type="submit">Register Vehicle</Button>
      </form>
    </div>
  )
}

