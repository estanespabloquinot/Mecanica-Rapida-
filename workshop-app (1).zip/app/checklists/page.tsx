"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"

const checklistItems = [
  "Electrical OK?",
  "Brake pads OK?",
  "Engine oil low?",
  "Tires bad?",
  "Fenders bad?",
  "Reverse siren?",
]

export default function ChecklistPage() {
  const [plate, setPlate] = useState("")
  const [currentKm, setCurrentKm] = useState("")
  const [checklistResponses, setChecklistResponses] = useState<Record<string, boolean>>({})
  const [descriptions, setDescriptions] = useState<Record<string, string>>({})
  const [additionalItems, setAdditionalItems] = useState<string[]>([])

  const handleChecklistChange = (item: string, checked: boolean) => {
    setChecklistResponses((prev) => ({ ...prev, [item]: checked }))
  }

  const handleDescriptionChange = (item: string, description: string) => {
    setDescriptions((prev) => ({ ...prev, [item]: description }))
  }

  const handleAddItem = () => {
    setAdditionalItems((prev) => [...prev, ""])
  }

  const handleAdditionalItemChange = (index: number, value: string) => {
    setAdditionalItems((prev) => {
      const newItems = [...prev]
      newItems[index] = value
      return newItems
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implement checklist submission logic
    console.log("Checklist submitted:", { plate, currentKm, checklistResponses, descriptions, additionalItems })
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Maintenance Checklist</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="plate">License Plate</Label>
          <Input id="plate" value={plate} onChange={(e) => setPlate(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="currentKm">Current KM</Label>
          <Input
            id="currentKm"
            type="number"
            value={currentKm}
            onChange={(e) => setCurrentKm(e.target.value)}
            required
          />
        </div>
        {checklistItems.map((item) => (
          <div key={item} className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id={item}
                checked={checklistResponses[item] || false}
                onCheckedChange={(checked) => handleChecklistChange(item, checked as boolean)}
              />
              <Label htmlFor={item}>{item}</Label>
            </div>
            {!checklistResponses[item] && (
              <Textarea
                placeholder="Description"
                value={descriptions[item] || ""}
                onChange={(e) => handleDescriptionChange(item, e.target.value)}
              />
            )}
          </div>
        ))}
        {additionalItems.map((item, index) => (
          <div key={index}>
            <Input
              value={item}
              onChange={(e) => handleAdditionalItemChange(index, e.target.value)}
              placeholder="Additional item to check"
            />
          </div>
        ))}
        <Button type="button" onClick={handleAddItem}>
          Add Item
        </Button>
        <Button type="submit">Submit Checklist</Button>
      </form>
    </div>
  )
}

