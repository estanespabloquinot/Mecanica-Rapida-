"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/contexts/AuthContext"

const checklistItems = [
  "Elétrica OK?",
  "Lonas de freio OK?",
  "Óleo de motor baixo?",
  "Pneu ruim?",
  "Paralamas ruim?",
  "Sirene de ré?",
]

interface Checklist {
  id: string
  placa: string
  kmAtual: number
  respostas: Record<string, boolean>
  descricoes: Record<string, string>
  itensAdicionais: string[]
  data: string
  usuarioId: string
}

export default function ChecklistPage() {
  const [placa, setPlaca] = useState("")
  const [kmAtual, setKmAtual] = useState("")
  const [respostas, setRespostas] = useState<Record<string, boolean>>({})
  const [descricoes, setDescricoes] = useState<Record<string, string>>({})
  const [itensAdicionais, setItensAdicionais] = useState<string[]>([])
  const [checklists, setChecklists] = useState<Checklist[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const storedChecklists = localStorage.getItem("checklists")
    if (storedChecklists) {
      setChecklists(JSON.parse(storedChecklists))
    }
  }, [])

  const handleChecklistChange = (item: string, checked: boolean) => {
    setRespostas((prev) => ({ ...prev, [item]: checked }))
  }

  const handleDescricaoChange = (item: string, descricao: string) => {
    setDescricoes((prev) => ({ ...prev, [item]: descricao }))
  }

  const adicionarItem = () => {
    setItensAdicionais((prev) => [...prev, ""])
  }

  const handleItemAdicionalChange = (index: number, valor: string) => {
    setItensAdicionais((prev) => {
      const novosItens = [...prev]
      novosItens[index] = valor
      return novosItens
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      console.error("Usuário não autenticado")
      return
    }

    const novoChecklist: Checklist = {
      id: Date.now().toString(),
      placa,
      kmAtual: Number(kmAtual),
      respostas,
      descricoes,
      itensAdicionais,
      data: new Date().toISOString(),
      usuarioId: user.id,
    }

    const novosChecklists = [...checklists, novoChecklist]
    setChecklists(novosChecklists)
    localStorage.setItem("checklists", JSON.stringify(novosChecklists))

    setPlaca("")
    setKmAtual("")
    setRespostas({})
    setDescricoes({})
    setItensAdicionais([])
  }

  if (!user) {
    return <div>Você precisa estar logado para acessar esta página.</div>
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Checklist de Manutenção</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="placa">Placa</Label>
          <Input id="placa" value={placa} onChange={(e) => setPlaca(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="kmAtual">KM Atual</Label>
          <Input id="kmAtual" type="number" value={kmAtual} onChange={(e) => setKmAtual(e.target.value)} required />
        </div>
        {checklistItems.map((item) => (
          <div key={item} className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id={item}
                checked={respostas[item] || false}
                onCheckedChange={(checked) => handleChecklistChange(item, checked as boolean)}
              />
              <Label htmlFor={item}>{item}</Label>
            </div>
            {!respostas[item] && (
              <Textarea
                placeholder="Descrição"
                value={descricoes[item] || ""}
                onChange={(e) => handleDescricaoChange(item, e.target.value)}
              />
            )}
          </div>
        ))}
        {itensAdicionais.map((item, index) => (
          <div key={index}>
            <Input
              value={item}
              onChange={(e) => handleItemAdicionalChange(index, e.target.value)}
              placeholder="Item adicional para verificar"
            />
          </div>
        ))}
        <Button type="button" onClick={adicionarItem}>
          Adicionar Item
        </Button>
        <Button type="submit">Salvar Checklist</Button>
      </form>

      <h2 className="text-xl font-bold mt-8">Checklists Realizados</h2>
      <ul className="space-y-4">
        {checklists.map((checklist) => (
          <li key={checklist.id} className="border p-4 rounded">
            <p>Placa: {checklist.placa}</p>
            <p>KM Atual: {checklist.kmAtual}</p>
            <p>Data: {new Date(checklist.data).toLocaleString()}</p>
            <h3 className="font-bold mt-2">Respostas:</h3>
            <ul>
              {Object.entries(checklist.respostas).map(([item, resposta]) => (
                <li key={item}>
                  {item}: {resposta ? "Sim" : "Não"}
                  {!resposta && checklist.descricoes[item] && (
                    <p className="ml-4">Descrição: {checklist.descricoes[item]}</p>
                  )}
                </li>
              ))}
            </ul>
            {checklist.itensAdicionais.length > 0 && (
              <>
                <h3 className="font-bold mt-2">Itens Adicionais:</h3>
                <ul>
                  {checklist.itensAdicionais.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

