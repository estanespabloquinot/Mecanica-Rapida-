"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function PerfilPage() {
  const [nome, setNome] = useState("")
  const [email, setEmail] = useState("")

  const handleSalvar = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implementar lógica para salvar o perfil
    console.log("Perfil salvo:", { nome, email })
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Meu Perfil</h1>
      <form onSubmit={handleSalvar} className="space-y-4">
        <div>
          <Label htmlFor="nome">Nome</Label>
          <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="email">E-mail</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <Button type="submit">Salvar</Button>
      </form>
    </div>
  )
}

